from pymongo import MongoClient

from bson.objectid import ObjectId

import json



class AnimalShelter(object):

    """ CRUD operations for Animal collection in MongoDB """



    def __init__(self, username, password):

        # Initializing the MongoClient. This helps to 

        # access the MongoDB databases and collections. 

        self.client = MongoClient('mongodb://%s:%s@localhost:54933' % (username, password))

        self.database = self.client['AAC']
    
# Update Method to implement the U in CRUD

    def update(self, data: dict, updateString: dict):
        if data is not None and updateString is not None:
            result = self.database.animals.update_one(data, updateString, upsert=False)
            if result.modified_count != 0:
                print("Updated successfully")
                print("Records updated: " + str(result.modified_count))
                return result.raw_result
            else:
                raise Exception("Update error, check your data again")
        else:
            raise Exception("Nothing to find, because a least one of the data parameters is empty") 
            
#Delete method to implement the D in CRUD

    def delete(self, data: dict):
        if data is not None:
            result = self.database.animals.delete_one(data)
            if result.deleted_count != 0:
                print("Records deleted successfully " + str(result.deleted_count))
                print(str(result))
            else:
                print("Data not found, deletion failed!")
        else:
            raise Exception("Delete error, data does not exist in database")

# Complete this create method to implement the C in CRUD.

    def create(self, data):

        if data is not None:

            self.database.animals.insert(data)  # data should be dictionary

        else:

            raise Exception("Nothing to save, because data parameter is empty")

            

# Create method to implement the R in CRUD. 

    def read(self, data):

        if data is not None:
        
            return self.database.animals.find(data, {"_id": False}) # returns the data that it finds

        else:

            raise Exception("Nothing to find, because data parameter is empty")




